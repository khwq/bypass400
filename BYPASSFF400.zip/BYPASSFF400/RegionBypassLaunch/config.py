TARGET_REGION = "IND"
TARGET_COUNTRY_CODE = "IN"
TARGET_VERSION = "2.132.6"
TARGET_VERSION_CODE = "2019118525"

PATCH_MODE = "both"

OAUTH_DOMAINS = ["100067.connect.garena.com"]
LOGIN_DOMAINS = ["loginbp.ppmainecoonghj.com"]
CLIENT_DOMAINS = ["clientbp.ppmainecoonghj.com"]
ALL_GAME_DOMAINS = OAUTH_DOMAINS + LOGIN_DOMAINS + CLIENT_DOMAINS + [
    "dl.dir.freefiremobile.com",
    "sgevent.ggblueshark.com",
    "msdk.garena.com",
    "ff.garena.com",
    "garenanow.com",
]

# Discord Bot
DISCORD_BOT_TOKEN = "MTQ2MDI5MDY2MjkwOTA4Nzg1OA.Gpvdrf.Rb_JlKXYO4Zm_s4l0nedJHu2pzY1Hfy0W4rELg"
DISCORD_LOG_CHANNEL_ID = 1518118425812144258
DISCORD_ADMIN_ROLE = "Bypass Admin"
